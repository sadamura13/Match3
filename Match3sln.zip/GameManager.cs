﻿using System;

using Microsoft.Xna.Framework.Audio;

using Match3.Core;
using Match3.Scenes;
using Match3.World;


namespace Match3
{
    public class GameManager : GameObject
    {
        private const int FieldWidth = 8;
        private const int FieldHeight = 8;
        private const float LevelTime = 60;

        public int Score
        { get; private set; }

        private GridManager gridManager;
        private UIManager uiManager;

        private SoundEffect chainClearedSound;
        private float endTime;
        private bool noTimeLeft;

        public GameManager()
        {
            uiManager = new UIManager(LevelTime);
            uiManager.RestartPressed += RestartPressedHandler;
            uiManager.MenuPressed += MenuPressedHandler;

            gridManager = new GridManager(FieldWidth, FieldHeight);
            gridManager.LineCleared += LineClearedHandler;
            gridManager.BombCleared += BombClearedHandler;
            gridManager.ChainCleared += ChainClearedHandler;

            Game1.Scene.AddToScene(uiManager);
            Game1.Scene.AddToScene(gridManager);

            chainClearedSound = Game1.LoadContent<SoundEffect>("Sound/ChainCleared");
            endTime = Game1.Time + LevelTime;
        }

        protected override void OnUpdate()
        {
            noTimeLeft = endTime - Game1.Time < 0;

            if (noTimeLeft)
            {
                if (gridManager.IsEnabled && !gridManager.FieldAnimating)
                {
                    gridManager.IsEnabled = false;
                    uiManager.CurrentScreen = GameScreen.Result;
                }
            }
        }

        private void AddScore(int score, int multiplier)
        {
            var pitch = multiplier / 5f;

            Score += score * multiplier;
            uiManager.AddScore(score, multiplier);
            chainClearedSound.Play(1, pitch > 1 ? 1 : pitch, 0);
        }

        #region Events

        private void RestartPressedHandler(object sender, EventArgs e)
        {
            Game1.LoadScene(new GameScene());
        }

        private void MenuPressedHandler(object sender, EventArgs e)
        {
            Game1.LoadScene(new MenuScene());
        }

        private void LineClearedHandler(object sender, ChainClearedEventArgs e)
        {
            AddScore(e.ChainLength * 100, e.Multiplier);
        }

        private void BombClearedHandler(object sender, ChainClearedEventArgs e)
        {
            AddScore(e.ChainLength * 200, e.Multiplier);
        }

        private void ChainClearedHandler(object sender, ChainClearedEventArgs e)
        {
            AddScore(e.ChainLength * 50, e.Multiplier);
        }

        #endregion
    }
}
