﻿namespace Match3
{
    public enum GameScreen
    {
        Game,
        Result
    }
}
