﻿using System;
using System.Collections.Generic;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

using Match3.Core;
using Match3.Utilities;
using Match3.Scenes;

namespace Match3
{
    public class UIManager : GameObject
    {
        private struct ScoreLabel
        {
            public float CreationTime;
            public string Text;
        }

        public event EventHandler MenuPressed;
        public event EventHandler RestartPressed;

        public GameScreen CurrentScreen
        { get; set; }

        private int score;
        private float stopTime;
        private List<ScoreLabel> labels;
        private float labelAliveTime;

        private SpriteFont arial;

        private Texture2D leftLabelBackground;
        private Texture2D rightLabelBackground;

        private Texture2D butOk;
        private Texture2D butOkHighlighted;
        private ButtonState previousState;

        private Rect butOkRect;
        private bool highlighted;
        private float scale;

        private float resultScreenAlpha;

        public UIManager(float levelTime)
        {
            score = 0;
            stopTime = Game1.Time + levelTime;
            labels = new List<ScoreLabel>();
            labelAliveTime = 4;

            arial = Game1.LoadContent<SpriteFont>("Fonts/Arial");

            leftLabelBackground = Game1.LoadContent<Texture2D>("LeftLabelBackground");
            rightLabelBackground = Game1.LoadContent<Texture2D>("RightLabelBackground");
            butOk = Game1.LoadContent<Texture2D>("Menu/OkButton");
            butOkHighlighted = Game1.LoadContent<Texture2D>("Menu/OkButtonHighlighted");

            butOkRect = new Rect(new Vector2((Game1.Viewport.Width - butOk.Width) / 2,
                                                   ((Game1.Viewport.Height - butOk.Height) / 2) + 100),
                                       new Point(butOk.Width, butOk.Height));

            scale = 0;
        }

        public void AddScore(int scoreValue, int multiplier)
        {
            score += scoreValue * multiplier;

            labels.Add(new ScoreLabel()
            {
                CreationTime = Game1.Time,
                Text = " + " + scoreValue + (multiplier > 1 ? " x " + multiplier : "")
            });
        }

        protected override void OnUpdate()
        {
            switch (CurrentScreen)
            {
                case GameScreen.Game:
                    labels.RemoveAll((x) => Game1.Time - x.CreationTime > labelAliveTime);
                    break;
                case GameScreen.Result:
                    UpdateResultScreen();
                    break;
            }
        }

        private void UpdateResultScreen()
        {
            if (resultScreenAlpha < 0.85f)
                resultScreenAlpha += Game1.DeltaTime * 2;

            //var keyboardState = Keyboard.GetState();

            //if (keyboardState.IsKeyDown(Keys.Space))
            //    RestartPressed?.Invoke(this, EventArgs.Empty);
            //else if (keyboardState.IsKeyDown(Keys.Escape))
            //    MenuPressed?.Invoke(this, EventArgs.Empty);

            if (scale < 1)
                scale += Game1.DeltaTime * 4;
            else
                scale = 1;

            var mouseState = Mouse.GetState();

            if (butOkRect.Contains(mouseState.Position))
            {
                highlighted = true;

                if (mouseState.LeftButton == ButtonState.Pressed &&
                    previousState == ButtonState.Released)
                    MenuPressed.Invoke(this, EventArgs.Empty);
            }
            else
            {
                highlighted = false;
            }

            previousState = mouseState.LeftButton;
        }

        protected override void OnDraw(SpriteBatch sBatch)
        {
            switch (CurrentScreen)
            {
                case GameScreen.Game:
                    DrawGameScreen(sBatch);
                    break;
                case GameScreen.Result:
                    DrawResultScreen(sBatch);
                    break;
            }
        }

        private void DrawGameScreen(SpriteBatch sBatch)
        {
            var scoreLabelPosition = new Vector2(20, 25);
            var timeLabelPosition = new Vector2(Game1.Viewport.Width - 130, 25);

            var scoreLabelBackgroundRect = new Rectangle(0, 0, 252, 84);
            var timeLabelBackgroundRect = new Rectangle(Game1.Viewport.Width - 252, 0, 252, 84);

            sBatch.Draw(leftLabelBackground, scoreLabelBackgroundRect, Color.White);
            sBatch.Draw(rightLabelBackground, timeLabelBackgroundRect, Color.White);

            var timeLeft = stopTime - Game1.Time > 0 ? stopTime - Game1.Time : 0;

            sBatch.DrawStringWithShadow(arial, $"Score: {score:000000}", scoreLabelPosition, Color.White);
            sBatch.DrawStringWithShadow(arial, $"{timeLeft:00.0}", timeLabelPosition, Color.White);

            for (int i = 0; i < labels.Count; ++i)
            {
                var position = new Vector2(20, 100 + (arial.LineSpacing * i));
                var alpha = (1 - (Game1.Time - labels[i].CreationTime) / labelAliveTime) / 3;

                sBatch.DrawString(arial, labels[i].Text, position, new Color(Color.Black, alpha));
            }
        }

        private void DrawResultScreen(SpriteBatch sBatch)
        {
            sBatch.DrawRect(Game1.Viewport.Bounds, new Color(Color.Black, resultScreenAlpha));

            sBatch.DrawStringFromCenter(arial, "Game Over",
                (Game1.Viewport.Bounds.Center + new Point(0, -50)).ToVector2(), Color.White);
            sBatch.DrawStringFromCenter(arial, "Score: " + score, Game1.Viewport.Bounds.Center.ToVector2(), Color.White);

            if (highlighted)
                sBatch.Draw(butOkHighlighted, butOkRect.ScaleFromCenter(scale));
            else
                sBatch.Draw(butOk, butOkRect.ScaleFromCenter(scale));

        }
    }
}
