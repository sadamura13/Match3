﻿using System;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Match3.Core;
using Match3.Utilities;
using Match3.World.Animation;


namespace Match3.World
{
    public class Block
    {
        public static BlockType GetRandomBlockType()
        {
            var types = Enum.GetValues(typeof(BlockType));
            var type = (BlockType)types.GetValue(Utils.GetRand(0, types.Length));

            return type;
        }

        public static void GetTexture(BlockType blockType,
                                      out Texture2D texture,
                                      out Texture2D selected)
        {
            var name = blockType.ToString();

            texture = Game1.LoadContent<Texture2D>($"Blocks/{name}");
            selected = Game1.LoadContent<Texture2D>($"Blocks/{name}_Selected");
        }

        public static void GetBonusTexture(BlockBonusType bonusType,
                                           out Texture2D texture)
        {
            if (bonusType == BlockBonusType.None)
            {
                texture = null;
                return;
            }

            var name = bonusType.ToString();

            texture = Game1.LoadContent<Texture2D>($"Blocks/Bonus_{name}");
        }

        public bool IsAnimating
        {
            get
            {
                return animation != null && animation.Animating;
            }
        }

        public BlockBonusType Bonus
        { get; }
        public BlockType Type
        { get; }

        public int X => GridPosition.X;
        public int Y => GridPosition.Y;

        public Point GridPosition
        { get; set; }
        public Rect ViewRect
        { get; set; }
        public bool Selected
        { get; set; }

        private Texture2D bonusTexture;
        private BlockAnimation animation;
        private Rect drawRect;
        private Texture2D texture;
        private Texture2D selected;
        private Color color;

        public Block(Point gridPosition, Vector2 viewPosition, Point viewSize,
                     BlockType? blockType = null, BlockBonusType? blockBonus = null)
        {
            Type = blockType ?? GetRandomBlockType();
            Bonus = blockBonus ?? BlockBonusType.None;

            GridPosition = gridPosition;
            ViewRect = new Rect(viewPosition, viewSize);

            GetTexture(Type, out texture, out selected);
            GetBonusTexture(Bonus, out bonusTexture);

            color = Color.White;
        }

        public void AttachAnimation(BlockAnimation animation)
        {
            if (IsAnimating)
                return;

            this.animation = animation;
            this.animation.Load(this);
        }

        public void Update()
        {
            if (IsAnimating)
            {
                drawRect = animation.Update(ViewRect);

                if (!animation.Animating)
                    animation.Stop();
            }
            else
            {
                if (drawRect != ViewRect)
                    drawRect = ViewRect;
            }
        }

        public void Draw(SpriteBatch sBatch)
        {
            if (Bonus != BlockBonusType.None)
            {
                sBatch.Draw(bonusTexture, drawRect);
                sBatch.Draw(Selected ? selected : texture, drawRect.ScaleFromCenter(0.5f), color);
            }
            else
            {
                sBatch.Draw(Selected ? selected : texture, drawRect, color);
            }
        }
    }
}
