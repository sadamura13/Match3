﻿namespace Match3.World
{
    public enum BlockBonusType
    {
        None,
        Bomb,
        HorizontalLine,
        VerticalLine
    }
}
