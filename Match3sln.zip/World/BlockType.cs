﻿namespace Match3.World
{
    public enum BlockType
    {
        Blue,
        Green,
        Orange,
        Pink,
        Yellow
    }
}
