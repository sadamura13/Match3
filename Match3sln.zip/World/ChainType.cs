﻿namespace Match3.World
{
    public enum ChainType
    {
        Horizontal,
        Vertical,
        Intersection
    }
}
